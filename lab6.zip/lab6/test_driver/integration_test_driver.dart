import 'package:integration_test/integration_test_driver.dart';

void main() => integrationDriver();